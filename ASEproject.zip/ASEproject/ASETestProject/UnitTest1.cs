using Microsoft.VisualStudio.TestTools.UnitTesting;
using ASEproject;

namespace ASETestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}